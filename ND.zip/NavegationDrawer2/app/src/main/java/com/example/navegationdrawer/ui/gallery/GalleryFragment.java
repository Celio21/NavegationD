package com.example.navegationdrawer.ui.gallery;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.example.navegationdrawer.R;
import com.example.navegationdrawer.ui.gallery.database.Persona;
import com.example.navegationdrawer.ui.gallery.database.PersonaLab;

import java.util.ArrayList;

public class GalleryFragment extends Fragment {
    private ArrayList<Persona> listaNombres=new ArrayList<>();
    private GalleryViewModel galleryViewModel;
    private PersonaLab mPersonaLab;
    private Persona mPersona;
    private ListAdapter listItemAdapter;
    private TextView guardar;
    private Button bguardar,blimpiar ,bteditar;
    private ListView listView;



    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        galleryViewModel =
                ViewModelProviders.of(this).get(GalleryViewModel.class);
        View root = inflater.inflate(R.layout.fragment_gallery, container, false);
        guardar = root.findViewById(R.id.guardar);
        bguardar=root.findViewById(R.id.buttonGuardar);
        bteditar=root.findViewById(R.id.bteditar);
         blimpiar=root.findViewById(R.id.buttonLimpiar);
        listView=root.findViewById(R.id.list);
       // listItemAdapter=new ListAdapter(getActivity().listaNombres);





        galleryViewModel.getText().observe(getViewLifecycleOwner(), new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
               // guardar.setText("Celio dice :");

            }
        });
        return root;
    }
    public void insertPersonas() {
        mPersona=new Persona();
        mPersona.setNombre(guardar.getText().toString());
        mPersonaLab.addPersona(mPersona);
        guardar.setText(" ");

    }
    public void getAllPersonas(){
        listaNombres.clear();
        listaNombres.addAll(mPersonaLab.getPersonas());

    }


}